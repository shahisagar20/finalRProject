kfunction <-
function(x){
  out = removeOutliers(x)
  
  y = 0
  j=1
  for(i in out){
    if(!is.na(i)){
      y[j] = i
      j =j+1
    }
  }
  m = ourmean(y)
  par(mfrow =c(2,3))
  plot(density(y, kernel = "gaussian", bw = m), col = "red", main = "Gaussian K")
  plot(density(y, kernel = "cosine", bw =m), col = "red", main = "Cosine K")
  plot(density(y, kernel = "rectangular", bw =m), col = "red", main = "Rect K")
  plot(density(y, kernel = "triangular", bw =m), col = "red", main = "Triangular K")
  plot(density(y, kernel = "epanechnikov", bw =m), col = "red", main = "epanechnikov K")
  plot(density(y, kernel = "biweight", bw =m), col = "red", main = "biweight K")
  
}
