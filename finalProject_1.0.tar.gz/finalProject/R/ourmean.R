ourmean <-
function(x){
  j=1
  y = 0
  out = removeOutliers(x)
  
  for(i in out){
    if(!is.na(i)){
      y[j] = i
      j =j+1
    }
  }
  return(mean(y))
  
}
