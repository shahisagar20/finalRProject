removeOutliers <-
function(x){
  j =1
  y = 0
  
  #Checks if the given data is numeric or not 
  #If the data is not numeric then it asks the user to put numeric data
  if(class(x) == 'numeric' & length(x) != 0 | class(x)=='integer'){
    for(i in x){
      if(!is.na(i)){
        y[j] = i
        j =j+1
      }
    }
    first_quartile = quantile(y, 0.25)
    third_quartile = quantile(y, 0.75)
    Inner_Quartile_Range = third_quartile - first_quartile
    leveler = 1.5*Inner_Quartile_Range
    minleveler = first_quartile - leveler
    maxleveler = third_quartile + leveler
    
    output = NULL
    for(i in 1:length(y)){
      if(y[i]> minleveler & y[i] < maxleveler ){
        output[i] = y[i]
      }
    }
    return(output)
  }else{
    print("The input data should be numeric or integer. ")
  }
}
